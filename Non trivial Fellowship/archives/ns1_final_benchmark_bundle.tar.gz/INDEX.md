# Final Benchmark Bundle — Dengue NS1 β-Ladder Binder Campaign

## Contents

- `final_ranked_binder_table.csv` — all 32 Boltz-2-validated designs from the
  seed-5 refinement campaign, contact-first ranked. 0/32 pass the locked
  acceptance gate (pLDDT>0.80, ipTM>0.7, interface pAE<5A, >=3 epitope contacts).

- `figures/01_denv1-4_conservation.png` — DENV1-4 pan-serotype conservation
  across the beta-ladder epitope. 4/5 designed hotspots match all four
  reference serotypes AND the actual modeling target sequence; position 272
  is a conservative but non-identical divergence (R in target vs K in refs).

- `figures/02_campaign_master_summary.png` — the campaign's key finding:
  Boltz-2 ipTM vs. physical epitope contacts, across all 32 designs from both
  refinement rounds. 0/32 designs are simultaneously high-confidence and
  on-epitope.

- `figures/03_seed5_robustness.png` — the origin of the "seed 5" lead: a
  6-seed Boltz-2 ensemble on the original nb_3:NS1 complex showing the
  on-epitope pose is reproducible (3/6 seeds) while the highest-ipTM seeds are
  consistently off-epitope — the first appearance of the inversion pattern.

- `figures/04_phase1_rf2_summary.png` — RF2 pre-filter results (48 partial-
  diffusion designs from seed 5), corrected for a heavy-atom/clash-floor
  contact-counting bug found during this campaign.

- `figures/05_phase2_boltz_epitope_fidelity.png` — Boltz-2 validation of the
  16-design Phase 2 shortlist (direct seed-5 refinement): 0/16 pass gate.

- `figures/06_phase1b_boltz_epitope_fidelity.png` — Boltz-2 validation of the
  16-design Phase 2b shortlist (re-seeded specifically from the one
  on-epitope design): 0/16 pass gate — 4th independent replication of the
  inversion.

## Headline result

Across four independent experiments in this campaign, Boltz-2's ipTM
confidence score and physical epitope fidelity to the NS1 beta-ladder region
are consistently anti-correlated for this nanobody scaffold. 0 of 32 refined
designs (and 0 of 5 from an earlier de novo round, not pictured here) pass
the full locked acceptance gate.

See `../README.md` and `../seed5_refinement_methods.md` (in the full project
repo bundle) for complete methodology, provenance, and disclosed data-
integrity corrections.
