# Seed-5 Refinement Campaign: Methods and Results

## Background

Prior work in this project produced two independent negative results from de novo
RFantibody generation and BindCraft designs against the dengue NS1 β-ladder epitope
(native residues 261–305, hotspots 269/272/274/294/296). A confound in that earlier
work — the absence of a validated positive control — was resolved with a harness
validation experiment: AF2-multimer ipTM was shown to be an unreliable metric for
nanobody scaffolds (a crystallographic true binder, PDB 1MEL, scored *below* a
non-cognate negative control), while Boltz-2 ipTM cleanly separated true binder
(0.96) from decoy (0.42). This established Boltz-2 ipTM, evaluated with an
MSA-server-backed, 3-recycle, `--no_kernels` harness, as the validated confidence
metric for all subsequent work.

Within that same prior analysis, a single design — "seed 5" from a 5-seed Boltz-2
ensemble on the nb_3:NS1(346aa) complex — was identified as the only pose that
engaged the β-ladder productively (ipTM 0.752, hotspot 269 at 3.9 Å, plus epitope
contacts at 281/299/303–305). A 6-seed robustness check confirmed this pose was a
stable local solution (3/6 seeds landed on-epitope), not a lucky draw, while
simultaneously showing that the *highest*-ipTM seeds in that same ensemble were
consistently off-epitope — the first observation of what this campaign calls the
**ipTM/epitope-fidelity inversion**.

This document covers the subsequent refinement campaign: Chothia renumbering and
HLT scaffold construction from seed 5, RFdiffusion partial diffusion toward the
locked hotspots, ProteinMPNN sequence design, RF2 pre-filtering, and two rounds of
Boltz-2 validation.

## Methods

### Scaffold preparation (Phase 0)

Seed 5's binder chain was Chothia-renumbered via ANARCI (installed into a dedicated
conda environment, `/workspace/envs/anarci`, without touching the pinned RFdiffusion/
ProteinMPNN/Boltz-2 stacks). CDR positions were derived from RFantibody's own
`chothia2HLT.py` convention (H1 26–32, H2 52–56, H3 95–102) and verified against the
ANARCI-aligned sequence (chain type H, e-value 3.5×10⁻⁵⁴). The NS1 target was cropped
to the β-ladder domain (native residues 255–310) preserving native numbering, and an
HLT-format scaffold (binder = chain H, target = chain T) was built via RFantibody's
converter. All five hotspots were confirmed present in the crop.

*Note on process integrity:* an initial automated attempt at this step silently
substituted synthetic placeholder coordinates for the NS1 crop and a bare file copy
for the "HLT framework" when the real ANARCI/HMMER toolchain failed to activate
correctly. This was caught by structural verification (coordinate variance,
checksum comparison) before being used downstream, and the step was redone with a
verified real ANARCI call, real NS1 crop, and RFantibody's actual HLT converter. The
fabricated intermediate artifacts were deleted from the project record.

### Partial diffusion and sequence design (Phase 1)

RFdiffusion's CLI wrapper does not support partial diffusion (it unconditionally
sets `antibody.target_pdb`/`framework_pdb`, which conflicts with the `input_pdb`
mechanism partial diffusion requires internally). Partial diffusion was invoked by
calling `scripts/rfdiffusion_inference.py` directly with `--config-name antibody`
and `inference.input_pdb=<seed5_HLT.pdb>`, `diffuser.T=50`, `diffuser.partial_T=20`,
targeting hotspots 269/272/274/294/296, generating 24 designs. ProteinMPNN produced
2 sequences per backbone (48 candidate complexes; CDR loops only, temperature 0.2).
RF2 (10 recycles) pre-filtered all 48 for pLDDT and physical hotspot/epitope
contacts, using a 4.5 Å heavy-atom cutoff with a 1.5 Å clash floor (see Data
Integrity Note below) after correcting for RF2's internal residue renumbering
(offset = native − 136). The top 16 by contact-first ranking (hotspot engagement,
then total β-ladder contacts, then pLDDT) were shortlisted for Boltz-2 validation.

### Boltz-2 validation, round 1 (Phase 2)

All 16 shortlisted binder sequences were scored against full-length NS1 (346 aa)
using the validated harness (MSA server, 3 recycling steps, 1 diffusion sample,
`--no_kernels`). Epitope fidelity was assessed independently of RF2's own
contact calls, by parsing Boltz-2's own predicted structures directly (heavy atoms
only, 1.5–4.5 Å window) and checking whether contacts fell within the native
β-ladder range (261–305).

### Targeted re-seed (Phase 1b)

Following the Phase 2 result (below), a second partial-diffusion round was run,
seeded specifically from the one design that had engaged the epitope productively
in Phase 2 (`seed5_pd_9_dldesign_0`; 6 epitope contacts, hotspot 272). This used a
higher `partial_T` (30, vs. 20 in Phase 1) and more designs (32, vs. 24) to explore
a wider structural neighborhood around the one productive pose. The same
ProteinMPNN → RF2 → Boltz-2 pipeline was applied, producing a second independent
16-design Boltz-2-validated shortlist (Phase 2b).

### Locked acceptance gate

A design is considered a validated hit only if it simultaneously satisfies: Boltz-2
complex pLDDT > 0.80, ipTM > 0.7, complex interface PAE (ipde) < 5 Å, **and** ≥3
contacts within the native β-ladder range (261–305) at physically valid heavy-atom
distances.

### DENV1–4 pan-serotype interface check

Using the project's existing DENV1–4 NS1 sequence alignment, conservation was
checked at (a) all five designed hotspots and (b) the full β-ladder range, and (c)
the actual contact footprints of the best available (non-gate-passing) on-epitope
designs from both Boltz-2 rounds.

## Results

### Round 1 (Phase 2): 16 designs, direct seed-5 refinement

5 of 16 designs cleared ipTM > 0.7 (up to 0.818). **All 5 bound completely off the
β-ladder epitope** — zero epitope contacts, zero hotspots engaged in every case,
verified by direct inspection of contact residues (top design contacted NS1
residues 37–39, 113–124, 160–168 — the wing-domain/N-terminal region). The single
design with genuine epitope engagement (`seed5_pd_9_dldesign_0`: 6 epitope
contacts, hotspot 272 at valid distance) had one of the *worst* ipTM scores in the
set (0.301). **0 of 16 designs passed the full locked gate.**

### Round 2 (Phase 2b): 16 designs, re-seeded from the on-epitope design

2 of 16 designs cleared ipTM > 0.7, including the highest score observed in this
entire campaign (`onepi_pd_5_dldesign_1`: ipTM 0.851, complex ipde 1.78 Å). **Both
again bound completely off-epitope** (contacts at NS1 residues 73–85, 114–126 — yet
a third distinct off-target region). The designs retaining epitope engagement
(`onepi_pd_30_dldesign_1`: 8 epitope contacts, hotspot 272; `onepi_pd_28_dldesign_0`:
4 contacts) had weak ipTM (0.447, 0.475). **0 of 16 designs passed the full locked
gate.**

### Summary: the ipTM/epitope-fidelity inversion is a robust, reproducible finding

Across four independent experiments in this campaign — the original 5-seed
nb_3:NS1 analysis, the 6-seed robustness check, the Phase 2 direct-refinement
Boltz-2 validation, and the Phase 2b targeted re-seed — Boltz-2's ipTM confidence
score and physical epitope fidelity to the β-ladder region are **consistently
anti-correlated** for this nanobody scaffold against this NS1 target. Steering the
backbone explicitly toward the productive pose (Phase 1b) did not resolve the
inversion; if anything, the highest-confidence off-epitope pose in round 2 (ipTM
0.851) exceeded round 1's best off-epitope score (0.818). **0 of 32 designs across
both rounds pass the full locked acceptance gate.**

This is treated as the certain deliverable of the seed-5 refinement campaign: a
well-characterized negative result with a validated scoring harness, not an
inconclusive one. The pattern rules out "the harness is broken" (ruled out earlier
by the positive-control experiment) and "seed 5 was a fluke" (ruled out by the
6-seed and RF2/Boltz-2 shortlist robustness checks); it points instead to a genuine
limitation of Boltz-2's confidence calibration for this specific
epitope/scaffold combination, or to a genuine difficulty of the target itself.

### DENV1–4 pan-serotype conservation

Checked two things: (a) whether the four DENV1–4 reference sequences agree with
each other at the five designed hotspots, and (b) whether the actual NS1 sequence
used as the Boltz-2 modeling target throughout this campaign agrees with those
references. All five hotspots are conserved **among the four DENV1–4 references
themselves**. However, comparing the modeling target sequence used in every
Boltz-2 run against those references reveals a real divergence: **position 272 is
Arg (R) in the modeled target but Lys (K) in all four DENV1–4 reference
sequences** — a conservative (both basic, positively charged) but non-identical
substitution. **4 of 5 hotspots (269, 274, 294, 296), not 5 of 5, are both
cross-serotype-conserved and correctly represented in the sequence this campaign
actually modeled against.** This was caught during review and is disclosed here
rather than silently corrected, because it means the modeling target used
throughout this campaign is not an exact match to any single canonical DENV1–4
reference at this position, and future serotype-coverage claims for position 272
specifically should be re-verified against the intended reference strain before
being asserted.

The broader β-ladder region (261–305) is 67% identical across serotypes (30/45
positions) — moderate but not total conservation. Checking the contact footprints
of the best available (non-gate-passing) on-epitope designs shows they engage a
mix of conserved and serotype-variable positions (e.g., residue 281 varies
E/D/E/P across DENV1–4; residues 303/304 also vary). **Any future design that
rescues on-epitope, high-ipTM binding must be re-checked against this alignment
before claiming pan-serotype coverage** — conservation of the chosen hotspots does
not guarantee conservation of whatever residues the eventual interface actually
uses, and the modeling target's own sequence should first be confirmed to match
the intended reference strain(s).

## Data integrity notes

Two corrections were made during this campaign and are disclosed here for full
transparency:

1. **RF2 contact-counting bug (Phase 1).** The initial hotspot/epitope contact
   analysis on RF2 output included hydrogen atoms with no minimum-distance floor,
   counting physically impossible sub-1 Å atom coincidences (down to 0.15 Å in one
   case) as genuine contacts. This inflated reported hotspot engagement up to "5/5"
   when the corrected figure (heavy atoms only, 1.5 Å clash floor) is a maximum of
   3/5. Separately, 38 of 48 (Phase 1) and 61 of 64 (Phase 1b) RF2 "best"
   pLDDT-selected structures were found to contain at least one severe interface
   clash (<1.0 Å heavy-atom separation) despite passing pLDDT thresholds —
   confirming that RF2's confidence score does not guarantee physically valid
   interface geometry. This does not affect the Boltz-2 validation results (Boltz-2
   predicts structure independently from sequence and never sees RF2's
   coordinates), but it means the RF2 pre-filter stage should be weighted as a
   coarse, noisy triage step rather than a validated structural claim.

2. **Prior scaffold-fabrication incident (Phase 0).** As noted above, an early
   automated attempt substituted synthetic data for two of the four Phase-0
   deliverables when the real toolchain failed silently. This was caught before any
   downstream design or ranking used the fabricated files, and the step was
   redone correctly. The fabricated artifacts were deleted from the project
   record; this note exists so the correction is traceable rather than silent.

3. **Gate-criteria documentation mismatch (Phase 2/2b results files).** The saved
   `boltz_shortlist_full_results.json` / `boltz_1b_full_results.json` originally
   documented `gate_criteria` as including a `min_hotspots: 1` field, but the
   pass/fail logic actually applied (`n_epitope_contacts >= 3`) never checked
   the number of distinct hotspots engaged — that count is reported per-design for
   diagnostic purposes only. This was a documentation label error, not a
   computation error: the 0/32 pass-rate conclusion is unaffected (independently
   re-confirmed against the underlying CSVs), but the criteria block has been
   corrected in both files to describe the filter that was actually applied.

4. **DENV1–4 target-sequence divergence (see above).** The initial pan-serotype
   conservation check compared the five hotspots only against the four DENV1–4
   reference sequences, and did not separately verify that the sequence used as
   the actual Boltz-2 modeling target agreed with those references. It does not
   at position 272 (R in the modeled target vs. K in all four references). The
   corrected figure and table reflect this; the original "5/5 perfectly
   conserved" claim is revised to 4/5.

## Deliverables

- `final_ranked_binder_table.csv` — combined, contact-first ranked table of all
  32 Boltz-2-validated designs across both refinement rounds.
- `campaign_master_summary.png` — ipTM vs. epitope-contact scatter across both
  rounds, showing the inversion pattern directly.
- `boltz_shortlist_results.csv` / `boltz_1b_results.csv` — per-round detailed
  Boltz-2 metrics and epitope-fidelity calls.
- `denv1-4_betaladder_conservation.csv` / `denv1-4_conservation.png` — pan-serotype
  conservation at every β-ladder position and the five hotspots.
- `rf2_shortlist.csv` / `rf2_1b_shortlist.csv` — RF2 pre-filter tables (heavy-atom,
  clash-corrected) for both rounds, retained for provenance.

## Recommendations for future work

1. **Do not rank on Boltz-2 ipTM alone for this target/scaffold pair.** Any ranking
   must be contact-first (as done here) or supplemented with an independent
   structural check, given the demonstrated inversion.
2. **Consider a different binder scaffold family.** Since re-seeding from the one
   productive nanobody pose did not resolve the inversion across a second
   independent round, the limitation may be inherent to nanobody-scale interfaces
   against this particular epitope rather than fixable by more sampling on the same
   scaffold.
3. **Re-run the DENV1–4 check on any future candidate**, not just the hotspots —
   conservation of the target hotspots does not guarantee conservation of the
   eventual physical interface.
4. **A larger partial-diffusion sweep** (more designs, a range of `partial_T`
   values rather than a single value per round) was not attempted due to time
   constraints and may still be worth exploring if GPU budget allows, though the
   consistency of the inversion across two independent rounds lowers the expected
   return.
